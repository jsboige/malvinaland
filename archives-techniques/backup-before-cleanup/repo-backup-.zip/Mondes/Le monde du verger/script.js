// Script de base pour le monde du verger
document.addEventListener('DOMContentLoaded', () => {
    console.log('Bienvenue dans le monde du verger!');
});